- For executing the code for all three parts, please type make:
$ make
