#Instruction
- Use command "make" or "python ia_2.py" in order to run the code
- Use "make plot" or "python ia_2.py -p" to store the plots into file
- Use "make save" or "python ia_2.py -s" to save the kernel tables for faster future runs

