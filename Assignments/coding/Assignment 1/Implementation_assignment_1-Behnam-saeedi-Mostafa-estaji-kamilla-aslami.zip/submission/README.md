Instructions:

- Programming language used is python 2.7

- For running the code by itself run:
- make

- For running the code with plots:
- make plot

- For running the code in high performance mode
- make highperformance

- For running the code in both high performance and plot mode run:
- make hpp

